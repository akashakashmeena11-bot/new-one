import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import TeamMemberCard from '@/components/TeamMemberCard.jsx';

const TeamPage = () => {
  const team = [
    {
      name: 'Maya Chen',
      role: 'Founder & Creative Director',
      bio: 'With 12 years in brand strategy, Maya leads our creative vision and ensures every project delivers authentic impact.',
      image: 'https://images.unsplash.com/photo-1577962917302-cd874c4e31d2',
      social: {
        linkedin: 'https://linkedin.com',
        twitter: 'https://twitter.com',
        email: 'maya@ilscollectives.com'
      }
    },
    {
      name: 'Raj Patel',
      role: 'Head of Strategy',
      bio: 'Raj brings data-driven insights to brand positioning, helping clients find their unique voice in crowded markets.',
      image: 'https://images.unsplash.com/photo-1577962917302-cd874c4e31d2',
      social: {
        linkedin: 'https://linkedin.com',
        email: 'raj@ilscollectives.com'
      }
    },
    {
      name: 'Lucia Torres',
      role: 'PR Director',
      bio: 'A former journalist with connections across major media outlets, Lucia crafts stories that journalists want to tell.',
      image: 'https://images.unsplash.com/photo-1577962917302-cd874c4e31d2',
      social: {
        linkedin: 'https://linkedin.com',
        twitter: 'https://twitter.com',
        email: 'lucia@ilscollectives.com'
      }
    },
    {
      name: 'Kwame Asante',
      role: 'Content Lead',
      bio: 'Kwame transforms complex ideas into compelling narratives that resonate across platforms and audiences.',
      image: 'https://images.unsplash.com/photo-1577962917302-cd874c4e31d2',
      social: {
        linkedin: 'https://linkedin.com',
        email: 'kwame@ilscollectives.com'
      }
    },
    {
      name: 'Anika Bergström',
      role: 'Design Director',
      bio: 'Anika leads our visual identity work, creating brand systems that are both beautiful and functional.',
      image: 'https://images.unsplash.com/photo-1577962917302-cd874c4e31d2',
      social: {
        linkedin: 'https://linkedin.com',
        twitter: 'https://twitter.com',
        email: 'anika@ilscollectives.com'
      }
    },
    {
      name: 'Jordan Kim',
      role: 'Digital Strategist',
      bio: 'Jordan builds digital campaigns that drive engagement and deliver measurable results for our clients.',
      image: 'https://images.unsplash.com/photo-1577962917302-cd874c4e31d2',
      social: {
        linkedin: 'https://linkedin.com',
        email: 'jordan@ilscollectives.com'
      }
    }
  ];

  return (
    <>
      <Helmet>
        <title>Our team - ILS Collectives</title>
        <meta name="description" content="Meet the talented team behind ILS Collectives. Experts in branding, PR, strategy, and creative storytelling." />
      </Helmet>

      <Header />

      <main className="pt-20">
        <section className="py-24 gradient-dark noise-overlay">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="max-w-4xl mx-auto text-center"
            >
              <h1 className="text-4xl font-bold mb-6 md:text-5xl lg:text-6xl" style={{ letterSpacing: '-0.02em' }}>
                Meet the minds behind{' '}
                <span className="text-gradient">your brand story</span>
              </h1>
              <p className="text-lg leading-relaxed text-muted-foreground md:text-xl">
                A diverse team of strategists, creatives, and storytellers united by a passion for authentic brand communication.
              </p>
            </motion.div>
          </div>
        </section>

        <section className="py-24">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
              {team.map((member, index) => (
                <TeamMemberCard
                  key={index}
                  {...member}
                  index={index}
                />
              ))}
            </div>
          </div>
        </section>

        <section className="py-24 bg-muted/30">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="max-w-3xl mx-auto text-center"
            >
              <h2 className="text-3xl font-bold mb-6 md:text-4xl">
                Join our collective
              </h2>
              <p className="text-lg leading-relaxed text-muted-foreground mb-8">
                We're always looking for talented individuals who share our passion for brand storytelling. If you're ready to make an impact, we'd love to hear from you.
              </p>
              <a 
                href="mailto:careers@ilscollectives.com"
                className="inline-flex items-center text-primary font-medium hover:underline"
              >
                View open positions
              </a>
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
};

export default TeamPage;