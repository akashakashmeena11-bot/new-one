import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Award, Users, Lightbulb, Heart } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';

const AboutPage = () => {
  const values = [
    {
      icon: Lightbulb,
      title: 'Innovation first',
      description: 'We challenge conventions and explore new approaches to brand storytelling.'
    },
    {
      icon: Heart,
      title: 'Authentic partnerships',
      description: 'Your success is our success. We build lasting relationships based on trust and results.'
    },
    {
      icon: Award,
      title: 'Excellence always',
      description: 'We hold ourselves to the highest standards in every project we undertake.'
    },
    {
      icon: Users,
      title: 'Collaborative spirit',
      description: 'Great work happens when diverse perspectives come together with a shared vision.'
    }
  ];

  return (
    <>
      <Helmet>
        <title>About us - ILS Collectives</title>
        <meta name="description" content="Learn about ILS Collectives, our mission to transform brand narratives, and the values that drive our work." />
      </Helmet>

      <Header />

      <main className="pt-20">
        <section className="py-24 gradient-dark noise-overlay">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="max-w-4xl mx-auto text-center"
            >
              <h1 className="text-4xl font-bold mb-6 md:text-5xl lg:text-6xl" style={{ letterSpacing: '-0.02em' }}>
                We believe every brand has a{' '}
                <span className="text-gradient">story worth telling</span>
              </h1>
              <p className="text-lg leading-relaxed text-muted-foreground md:text-xl">
                Founded in 2018, ILS Collectives emerged from a simple observation: too many great brands struggle to communicate their true value. We set out to change that.
              </p>
            </motion.div>
          </div>
        </section>

        <section className="py-24">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid gap-12 md:grid-cols-2 items-center">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <h2 className="text-3xl font-bold mb-6 md:text-4xl">
                  Our mission
                </h2>
                <p className="text-lg leading-relaxed text-muted-foreground mb-6">
                  We exist to help brands find their voice and share it with the world. Through strategic positioning, creative storytelling, and data-driven execution, we transform how companies connect with their audiences.
                </p>
                <p className="text-lg leading-relaxed text-muted-foreground">
                  Our work spans brand strategy, public relations, content creation, and digital marketing — all unified by a commitment to authentic, impactful communication.
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="grid grid-cols-2 gap-6"
              >
                {[
                  { value: '47', label: 'Brands served' },
                  { value: '8.2k', label: 'Stories told' },
                  { value: '92%', label: 'Client retention' },
                  { value: '6', label: 'Years of impact' }
                ].map((stat, index) => (
                  <div key={index} className="rounded-xl bg-card p-6 shadow-lg">
                    <div className="text-3xl font-bold text-primary mb-2">
                      {stat.value}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {stat.label}
                    </div>
                  </div>
                ))}
              </motion.div>
            </div>
          </div>
        </section>

        <section className="py-24 bg-muted/30">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="max-w-3xl mx-auto text-center mb-16"
            >
              <h2 className="text-3xl font-bold mb-4 md:text-4xl">
                Our values
              </h2>
              <p className="text-lg leading-relaxed text-muted-foreground">
                These principles guide every decision we make and every story we tell.
              </p>
            </motion.div>

            <div className="grid gap-8 md:grid-cols-2">
              {values.map((value, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="rounded-2xl bg-card p-8 shadow-lg"
                >
                  <div className="mb-4 inline-flex rounded-xl bg-primary/10 p-3 text-primary">
                    <value.icon className="h-6 w-6" />
                  </div>
                  <h3 className="mb-3 text-xl font-semibold">
                    {value.title}
                  </h3>
                  <p className="leading-relaxed text-muted-foreground">
                    {value.description}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-24">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="max-w-3xl mx-auto text-center"
            >
              <h2 className="text-3xl font-bold mb-6 md:text-4xl">
                The journey continues
              </h2>
              <p className="text-lg leading-relaxed text-muted-foreground mb-8">
                Every brand we work with teaches us something new. Every story we tell pushes us to think differently. We're constantly evolving, learning, and growing — because that's what it takes to stay at the forefront of brand communication.
              </p>
              <p className="text-lg leading-relaxed text-muted-foreground">
                Ready to write your next chapter? Let's talk.
              </p>
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
};

export default AboutPage;