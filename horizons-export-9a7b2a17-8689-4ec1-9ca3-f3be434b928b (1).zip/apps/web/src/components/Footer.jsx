import React from 'react';
import { Link } from 'react-router-dom';
import { Linkedin, Twitter, Instagram, Mail } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const quickLinks = [
    { path: '/', label: 'Home' },
    { path: '/about', label: 'About' },
    { path: '/services', label: 'Services' },
    { path: '/portfolio', label: 'Portfolio' }
  ];

  const socialLinks = [
    { icon: Linkedin, href: 'https://linkedin.com', label: 'LinkedIn' },
    { icon: Twitter, href: 'https://twitter.com', label: 'Twitter' },
    { icon: Instagram, href: 'https://instagram.com', label: 'Instagram' },
    { icon: Mail, href: 'mailto:hello@ilscollectives.com', label: 'Email' }
  ];

  return (
    <footer className="bg-card border-t border-border">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          <div>
            <span className="text-2xl font-bold text-gradient">
              ILS Collectives
            </span>
            <p className="mt-4 text-sm leading-relaxed text-card-foreground/80">
              Elite branding and PR agency crafting compelling narratives for forward-thinking brands.
            </p>
          </div>

          <div>
            <span className="text-sm font-semibold tracking-wide uppercase text-card-foreground">
              Quick links
            </span>
            <ul className="mt-4 space-y-2">
              {quickLinks.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="text-sm text-card-foreground/70 transition-colors duration-200 hover:text-primary"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <span className="text-sm font-semibold tracking-wide uppercase text-card-foreground">
              Contact
            </span>
            <ul className="mt-4 space-y-2 text-sm text-card-foreground/70">
              <li>hello@ilscollectives.com</li>
              <li>+1 (555) 123-4567</li>
              <li>New York, NY</li>
            </ul>
          </div>

          <div>
            <span className="text-sm font-semibold tracking-wide uppercase text-card-foreground">
              Follow us
            </span>
            <div className="mt-4 flex gap-3">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={social.label}
                  className="rounded-lg bg-muted p-2 text-card-foreground/70 transition-all duration-200 hover:bg-primary hover:text-primary-foreground"
                >
                  <social.icon className="h-5 w-5" />
                </a>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-border pt-8 md:flex-row">
          <p className="text-sm text-card-foreground/60">
            © {currentYear} ILS Collectives. All rights reserved.
          </p>
          <div className="flex gap-6 text-sm">
            <Link to="/privacy" className="text-card-foreground/60 transition-colors duration-200 hover:text-primary">
              Privacy Policy
            </Link>
            <Link to="/terms" className="text-card-foreground/60 transition-colors duration-200 hover:text-primary">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;