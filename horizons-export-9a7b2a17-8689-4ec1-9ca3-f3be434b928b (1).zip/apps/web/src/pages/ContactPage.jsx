import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import ContactForm from '@/components/ContactForm.jsx';

const ContactPage = () => {
  const contactInfo = [
    {
      icon: Mail,
      title: 'Email',
      value: 'hello@ilscollectives.com',
      link: 'mailto:hello@ilscollectives.com'
    },
    {
      icon: Phone,
      title: 'Phone',
      value: '+1 (555) 123-4567',
      link: 'tel:+15551234567'
    },
    {
      icon: MapPin,
      title: 'Office',
      value: 'New York, NY',
      link: null
    }
  ];

  return (
    <>
      <Helmet>
        <title>Contact us - ILS Collectives</title>
        <meta name="description" content="Get in touch with ILS Collectives. Let's discuss how we can help transform your brand narrative." />
      </Helmet>

      <Header />

      <main className="pt-20">
        <section className="py-24 gradient-dark noise-overlay">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="max-w-4xl mx-auto text-center"
            >
              <h1 className="text-4xl font-bold mb-6 md:text-5xl lg:text-6xl" style={{ letterSpacing: '-0.02em' }}>
                Let's start a{' '}
                <span className="text-gradient">conversation</span>
              </h1>
              <p className="text-lg leading-relaxed text-muted-foreground md:text-xl">
                Whether you have a specific project in mind or just want to explore possibilities, we'd love to hear from you.
              </p>
            </motion.div>
          </div>
        </section>

        <section className="py-24">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid gap-12 lg:grid-cols-2">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
              >
                <h2 className="text-3xl font-bold mb-6 md:text-4xl">
                  Get in touch
                </h2>
                <p className="text-lg leading-relaxed text-muted-foreground mb-8">
                  Fill out the form and we'll get back to you within 24 hours. For urgent inquiries, feel free to call us directly.
                </p>

                <div className="space-y-6">
                  {contactInfo.map((info, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, delay: 0.2 + index * 0.1 }}
                      className="flex items-start gap-4"
                    >
                      <div className="flex-shrink-0 rounded-xl bg-primary/10 p-3 text-primary">
                        <info.icon className="h-6 w-6" />
                      </div>
                      <div>
                        <h3 className="font-semibold mb-1">
                          {info.title}
                        </h3>
                        {info.link ? (
                          <a 
                            href={info.link}
                            className="text-muted-foreground hover:text-primary transition-colors duration-200"
                          >
                            {info.value}
                          </a>
                        ) : (
                          <p className="text-muted-foreground">
                            {info.value}
                          </p>
                        )}
                      </div>
                    </motion.div>
                  ))}
                </div>

                <div className="mt-12 rounded-2xl bg-card p-8 shadow-lg">
                  <h3 className="text-xl font-semibold mb-4">
                    Office hours
                  </h3>
                  <div className="space-y-2 text-muted-foreground">
                    <p>Monday - Friday: 9:00 AM - 6:00 PM EST</p>
                    <p>Saturday - Sunday: Closed</p>
                  </div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
                className="rounded-2xl bg-card p-8 shadow-xl"
              >
                <ContactForm />
              </motion.div>
            </div>
          </div>
        </section>

        <section className="py-24 bg-muted/30">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="max-w-3xl mx-auto text-center"
            >
              <h2 className="text-3xl font-bold mb-6 md:text-4xl">
                Prefer to meet in person?
              </h2>
              <p className="text-lg leading-relaxed text-muted-foreground mb-8">
                Our New York office is always open for coffee and conversation. Schedule a visit and let's discuss your brand goals face-to-face.
              </p>
              <a 
                href="mailto:hello@ilscollectives.com?subject=Office Visit Request"
                className="inline-flex items-center text-primary font-medium hover:underline"
              >
                Schedule a visit
              </a>
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
};

export default ContactPage;