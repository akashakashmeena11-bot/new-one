import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { ArrowRight, Sparkles, Target, Zap } from 'lucide-react';
import { Link } from 'react-router-dom';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import GradientButton from '@/components/GradientButton.jsx';

const HomePage = () => {
  return (
    <>
      <Helmet>
        <title>ILS Collectives - Elite branding and PR agency</title>
        <meta name="description" content="Transform your brand narrative with ILS Collectives. We craft compelling stories that resonate with your audience and drive meaningful engagement." />
      </Helmet>

      <Header />

      <main>
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden noise-overlay">
          <div 
            className="absolute inset-0 z-0"
            style={{
              backgroundImage: 'url(https://images.unsplash.com/photo-1697638164340-6c5fc558bdf2)',
              backgroundSize: 'cover',
              backgroundPosition: 'center'
            }}
          >
            <div className="absolute inset-0 bg-gradient-to-br from-background via-background/95 to-primary/20" />
          </div>

          <div className="container relative z-10 mx-auto px-4 sm:px-6 lg:px-8 py-32">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="max-w-4xl mx-auto text-center"
            >
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="mb-6 inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-2 text-sm font-medium text-primary"
              >
                <Sparkles className="h-4 w-4" />
                Elite branding and PR agency
              </motion.div>

              <h1 className="mb-6 text-5xl font-bold leading-tight md:text-6xl lg:text-7xl" style={{ letterSpacing: '-0.02em' }}>
                Craft narratives that{' '}
                <span className="text-gradient">transform brands</span>
              </h1>

              <p className="mb-10 text-lg leading-relaxed text-muted-foreground md:text-xl max-w-2xl mx-auto">
                We partner with forward-thinking companies to build authentic brand stories that resonate, engage, and drive measurable results.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link to="/contact">
                  <GradientButton size="lg">
                    Start your project
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </GradientButton>
                </Link>
                <Link to="/portfolio">
                  <GradientButton variant="outline" size="lg">
                    View our work
                  </GradientButton>
                </Link>
              </div>
            </motion.div>
          </div>
        </section>

        <section className="py-24 bg-muted/30">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="max-w-3xl mx-auto text-center mb-16"
            >
              <h2 className="text-3xl font-bold mb-4 md:text-4xl">
                Why brands choose us
              </h2>
              <p className="text-lg leading-relaxed text-muted-foreground">
                We combine strategic thinking with creative execution to deliver brand experiences that matter.
              </p>
            </motion.div>

            <div className="grid gap-8 md:grid-cols-3">
              {[
                {
                  icon: Target,
                  title: 'Strategic positioning',
                  description: 'We identify your unique market position and craft messaging that cuts through the noise.'
                },
                {
                  icon: Sparkles,
                  title: 'Creative excellence',
                  description: 'Our team brings fresh perspectives and innovative approaches to every brand challenge.'
                },
                {
                  icon: Zap,
                  title: 'Measurable impact',
                  description: 'Track real results with data-driven campaigns that move the needle on your business goals.'
                }
              ].map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="rounded-2xl bg-card p-8 shadow-lg"
                >
                  <div className="mb-4 inline-flex rounded-xl bg-primary/10 p-3 text-primary">
                    <feature.icon className="h-6 w-6" />
                  </div>
                  <h3 className="mb-3 text-xl font-semibold">
                    {feature.title}
                  </h3>
                  <p className="leading-relaxed text-muted-foreground">
                    {feature.description}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-24">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid gap-12 md:grid-cols-2 items-center">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <h2 className="text-3xl font-bold mb-6 md:text-4xl">
                  Built for brands that refuse to blend in
                </h2>
                <p className="text-lg leading-relaxed text-muted-foreground mb-6">
                  In a world of sameness, we help you stand out. Our approach combines deep market insights with bold creative thinking to position your brand where it belongs — at the forefront of your industry.
                </p>
                <p className="text-lg leading-relaxed text-muted-foreground mb-8">
                  From startups to established enterprises, we've helped 47 brands tell their stories with clarity, confidence, and impact.
                </p>
                <Link to="/about">
                  <GradientButton>
                    Learn more about us
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </GradientButton>
                </Link>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="relative"
              >
                <div className="aspect-square rounded-2xl overflow-hidden shadow-2xl shadow-primary/20">
                  <img 
                    src="https://images.unsplash.com/photo-1577962917302-cd874c4e31d2"
                    alt="Creative team collaboration"
                    className="h-full w-full object-cover"
                  />
                </div>
                <div className="absolute -bottom-6 -left-6 rounded-xl bg-primary p-6 shadow-xl">
                  <div className="text-4xl font-bold text-primary-foreground">92%</div>
                  <div className="text-sm text-primary-foreground/90">Client retention</div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
};

export default HomePage;