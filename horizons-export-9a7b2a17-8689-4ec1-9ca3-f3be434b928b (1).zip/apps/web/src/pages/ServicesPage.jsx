import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Compass, Megaphone, PenTool, BarChart3, Sparkles, Target } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import ServiceCard from '@/components/ServiceCard.jsx';

const ServicesPage = () => {
  const services = [
    {
      icon: Compass,
      title: 'Brand strategy',
      description: 'We define your unique market position, craft your brand narrative, and build a roadmap for authentic growth.'
    },
    {
      icon: Megaphone,
      title: 'Public relations',
      description: 'From media outreach to crisis management, we secure the coverage that matters and protect your reputation.'
    },
    {
      icon: PenTool,
      title: 'Content creation',
      description: 'Compelling stories across all formats — from thought leadership articles to social media campaigns that engage.'
    },
    {
      icon: BarChart3,
      title: 'Digital marketing',
      description: 'Data-driven campaigns that reach your audience where they are and drive measurable business results.'
    },
    {
      icon: Sparkles,
      title: 'Brand identity',
      description: 'Visual systems that capture your essence and create lasting impressions across every touchpoint.'
    },
    {
      icon: Target,
      title: 'Launch campaigns',
      description: 'Make your debut unforgettable with integrated campaigns that generate buzz and build momentum.'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Services - ILS Collectives</title>
        <meta name="description" content="Explore our comprehensive branding and PR services: strategy, public relations, content creation, digital marketing, and more." />
      </Helmet>

      <Header />

      <main className="pt-20">
        <section className="py-24 gradient-dark noise-overlay">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="max-w-4xl mx-auto text-center"
            >
              <h1 className="text-4xl font-bold mb-6 md:text-5xl lg:text-6xl" style={{ letterSpacing: '-0.02em' }}>
                Services that{' '}
                <span className="text-gradient">transform brands</span>
              </h1>
              <p className="text-lg leading-relaxed text-muted-foreground md:text-xl">
                From strategy to execution, we provide the full spectrum of branding and PR services your business needs to thrive.
              </p>
            </motion.div>
          </div>
        </section>

        <section className="py-24">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
              {services.map((service, index) => (
                <ServiceCard
                  key={index}
                  {...service}
                  index={index}
                />
              ))}
            </div>
          </div>
        </section>

        <section className="py-24 bg-muted/30">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid gap-12 md:grid-cols-2 items-center">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <h2 className="text-3xl font-bold mb-6 md:text-4xl">
                  Our approach
                </h2>
                <p className="text-lg leading-relaxed text-muted-foreground mb-6">
                  We don't believe in one-size-fits-all solutions. Every brand has unique challenges, opportunities, and stories to tell.
                </p>
                <p className="text-lg leading-relaxed text-muted-foreground mb-6">
                  Our process begins with deep discovery — understanding your business, your audience, and your goals. From there, we craft tailored strategies that align with your vision and deliver measurable impact.
                </p>
                <p className="text-lg leading-relaxed text-muted-foreground">
                  Whether you need a complete brand overhaul or targeted support for a specific initiative, we bring the same level of strategic thinking and creative excellence to every engagement.
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="space-y-6"
              >
                {[
                  { step: '01', title: 'Discovery', description: 'Deep dive into your brand, market, and objectives' },
                  { step: '02', title: 'Strategy', description: 'Craft a roadmap aligned with your vision' },
                  { step: '03', title: 'Execution', description: 'Bring the strategy to life with precision' },
                  { step: '04', title: 'Optimization', description: 'Measure, learn, and continuously improve' }
                ].map((phase, index) => (
                  <div key={index} className="flex gap-4">
                    <div className="flex-shrink-0">
                      <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary text-primary-foreground font-bold">
                        {phase.step}
                      </div>
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-2">
                        {phase.title}
                      </h3>
                      <p className="text-muted-foreground">
                        {phase.description}
                      </p>
                    </div>
                  </div>
                ))}
              </motion.div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
};

export default ServicesPage;