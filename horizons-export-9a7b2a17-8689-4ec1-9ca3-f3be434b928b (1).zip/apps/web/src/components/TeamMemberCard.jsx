import React from 'react';
import { motion } from 'framer-motion';
import { Linkedin, Twitter, Mail } from 'lucide-react';

const TeamMemberCard = ({ 
  image, 
  name, 
  role, 
  bio,
  social,
  index = 0 
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="group overflow-hidden rounded-2xl bg-card transition-all duration-300 hover:shadow-xl hover:shadow-primary/10"
    >
      <div className="aspect-square overflow-hidden">
        <img 
          src={image} 
          alt={name}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
      </div>
      
      <div className="p-6">
        <h3 className="mb-1 text-2xl font-semibold text-foreground">
          {name}
        </h3>
        
        <p className="mb-4 text-sm font-medium text-primary">
          {role}
        </p>
        
        <p className="mb-6 leading-relaxed text-muted-foreground">
          {bio}
        </p>
        
        {social && (
          <div className="flex gap-3">
            {social.linkedin && (
              <a 
                href={social.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="rounded-lg bg-muted p-2 text-muted-foreground transition-all duration-200 hover:bg-primary hover:text-primary-foreground"
              >
                <Linkedin className="h-5 w-5" />
              </a>
            )}
            {social.twitter && (
              <a 
                href={social.twitter}
                target="_blank"
                rel="noopener noreferrer"
                className="rounded-lg bg-muted p-2 text-muted-foreground transition-all duration-200 hover:bg-primary hover:text-primary-foreground"
              >
                <Twitter className="h-5 w-5" />
              </a>
            )}
            {social.email && (
              <a 
                href={`mailto:${social.email}`}
                className="rounded-lg bg-muted p-2 text-muted-foreground transition-all duration-200 hover:bg-primary hover:text-primary-foreground"
              >
                <Mail className="h-5 w-5" />
              </a>
            )}
          </div>
        )}
      </div>
    </motion.div>
  );
};

export default TeamMemberCard;