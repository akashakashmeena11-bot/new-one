import React from 'react';
import { motion } from 'framer-motion';
import { ArrowUpRight } from 'lucide-react';

const PortfolioCard = ({ 
  image, 
  title, 
  description, 
  category,
  results,
  index = 0 
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="group relative overflow-hidden rounded-2xl bg-card transition-all duration-300 hover:shadow-xl hover:shadow-primary/10"
    >
      <div className="aspect-[4/3] overflow-hidden">
        <img 
          src={image} 
          alt={title}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
      </div>
      
      <div className="p-6">
        <div className="mb-3 flex items-center justify-between">
          <span className="text-sm font-medium text-primary">
            {category}
          </span>
          <ArrowUpRight className="h-5 w-5 text-muted-foreground transition-all duration-300 group-hover:translate-x-1 group-hover:-translate-y-1 group-hover:text-primary" />
        </div>
        
        <h3 className="mb-3 text-2xl font-semibold text-foreground">
          {title}
        </h3>
        
        <p className="mb-4 leading-relaxed text-muted-foreground">
          {description}
        </p>
        
        {results && (
          <div className="flex flex-wrap gap-4 border-t border-border pt-4">
            {results.map((result, idx) => (
              <div key={idx} className="flex flex-col">
                <span className="text-2xl font-bold text-primary">
                  {result.value}
                </span>
                <span className="text-sm text-muted-foreground">
                  {result.label}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </motion.div>
  );
};

export default PortfolioCard;