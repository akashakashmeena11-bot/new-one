import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import PortfolioCard from '@/components/PortfolioCard.jsx';

const PortfolioPage = () => {
  const projects = [
    {
      image: 'https://images.unsplash.com/photo-1697638164340-6c5fc558bdf2',
      title: 'Meridian Labs',
      category: 'Brand strategy & launch',
      description: 'Positioned a biotech startup for Series A funding with a complete brand overhaul and targeted PR campaign.',
      results: [
        { value: '3.2M', label: 'Media reach' },
        { value: '47%', label: 'Brand awareness' }
      ]
    },
    {
      image: 'https://images.unsplash.com/photo-1577962917302-cd874c4e31d2',
      title: 'Coastal Roasters',
      category: 'Content & digital',
      description: 'Built a content ecosystem that transformed a local coffee brand into a regional lifestyle destination.',
      results: [
        { value: '8.4k', label: 'New followers' },
        { value: '127%', label: 'Engagement lift' }
      ]
    },
    {
      image: 'https://images.unsplash.com/photo-1697638164340-6c5fc558bdf2',
      title: 'Elm & Oak',
      category: 'Brand identity',
      description: 'Created a premium visual identity for a sustainable furniture brand entering the luxury market.',
      results: [
        { value: '92%', label: 'Client satisfaction' },
        { value: '2.1x', label: 'Sales growth' }
      ]
    },
    {
      image: 'https://images.unsplash.com/photo-1577962917302-cd874c4e31d2',
      title: 'Vertex Financial',
      category: 'Crisis management',
      description: 'Navigated a complex regulatory challenge with strategic communications that protected brand reputation.',
      results: [
        { value: '89%', label: 'Positive sentiment' },
        { value: '12', label: 'Media placements' }
      ]
    },
    {
      image: 'https://images.unsplash.com/photo-1697638164340-6c5fc558bdf2',
      title: 'Lumina Health',
      category: 'Thought leadership',
      description: 'Established C-suite executives as industry voices through strategic content and media relations.',
      results: [
        { value: '23', label: 'Speaking engagements' },
        { value: '6', label: 'Industry awards' }
      ]
    },
    {
      image: 'https://images.unsplash.com/photo-1577962917302-cd874c4e31d2',
      title: 'Urban Harvest',
      category: 'Product launch',
      description: 'Orchestrated a multi-channel campaign that generated buzz for a sustainable food delivery service.',
      results: [
        { value: '4.7k', label: 'Launch signups' },
        { value: '18', label: 'Press features' }
      ]
    }
  ];

  return (
    <>
      <Helmet>
        <title>Portfolio - ILS Collectives</title>
        <meta name="description" content="Explore our portfolio of successful brand transformations, PR campaigns, and creative projects across industries." />
      </Helmet>

      <Header />

      <main className="pt-20">
        <section className="py-24 gradient-dark noise-overlay">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="max-w-4xl mx-auto text-center"
            >
              <h1 className="text-4xl font-bold mb-6 md:text-5xl lg:text-6xl" style={{ letterSpacing: '-0.02em' }}>
                Work that{' '}
                <span className="text-gradient">speaks for itself</span>
              </h1>
              <p className="text-lg leading-relaxed text-muted-foreground md:text-xl">
                From startups to established brands, we've helped companies across industries tell their stories with impact.
              </p>
            </motion.div>
          </div>
        </section>

        <section className="py-24">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
              {projects.map((project, index) => (
                <PortfolioCard
                  key={index}
                  {...project}
                  index={index}
                />
              ))}
            </div>
          </div>
        </section>

        <section className="py-24 bg-muted/30">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="max-w-3xl mx-auto text-center"
            >
              <h2 className="text-3xl font-bold mb-6 md:text-4xl">
                Ready to write your success story?
              </h2>
              <p className="text-lg leading-relaxed text-muted-foreground mb-8">
                Every project in our portfolio started with a conversation. Let's start yours.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <a 
                  href="/contact"
                  className="inline-flex items-center justify-center rounded-xl gradient-primary px-8 py-3 text-base font-semibold text-white shadow-lg shadow-primary/20 transition-all duration-200 hover:shadow-xl hover:shadow-primary/30 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                >
                  Start a project
                </a>
              </div>
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
};

export default PortfolioPage;