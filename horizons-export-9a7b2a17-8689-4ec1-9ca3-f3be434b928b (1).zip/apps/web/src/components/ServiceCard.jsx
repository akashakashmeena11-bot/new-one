import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

const ServiceCard = ({ icon: Icon, title, description, index = 0 }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="group relative overflow-hidden rounded-2xl bg-card p-8 transition-all duration-300 hover:shadow-xl hover:shadow-primary/10 hover:-translate-y-1"
    >
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
      
      <div className="relative z-10">
        <div className="mb-6 inline-flex rounded-xl bg-primary/10 p-4 text-primary transition-all duration-300 group-hover:bg-primary group-hover:text-primary-foreground">
          <Icon className="h-8 w-8" />
        </div>
        
        <h3 className="mb-4 text-2xl font-semibold text-foreground">
          {title}
        </h3>
        
        <p className="leading-relaxed text-muted-foreground">
          {description}
        </p>
      </div>
    </motion.div>
  );
};

export default ServiceCard;