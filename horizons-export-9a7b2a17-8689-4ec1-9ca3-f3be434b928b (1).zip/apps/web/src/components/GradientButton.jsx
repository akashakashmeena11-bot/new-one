import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

const GradientButton = ({ 
  children, 
  className, 
  variant = 'primary',
  size = 'default',
  ...props 
}) => {
  const variants = {
    primary: 'gradient-primary text-white shadow-lg shadow-primary/20 hover:shadow-xl hover:shadow-primary/30',
    secondary: 'bg-secondary text-secondary-foreground hover:bg-secondary/90',
    outline: 'border-2 border-primary text-primary hover:bg-primary hover:text-primary-foreground',
    ghost: 'text-foreground hover:bg-muted'
  };

  const sizes = {
    default: 'px-8 py-3 text-base',
    sm: 'px-6 py-2 text-sm',
    lg: 'px-10 py-4 text-lg'
  };

  return (
    <motion.button
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      className={cn(
        'rounded-xl font-semibold transition-all duration-200',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2',
        variants[variant],
        sizes[size],
        className
      )}
      {...props}
    >
      {children}
    </motion.button>
  );
};

export default GradientButton;